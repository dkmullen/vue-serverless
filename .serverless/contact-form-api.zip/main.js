const form = document.getElementById('contactForm')
const url = 'https://sv0i991s0e.execute-api.us-east-2.amazonaws.com/dev/email/send'
const toast = document.getElementById('toast')
// const submit = document.getElementById('submit')

var app = new Vue({
    el: '#app',
    data: {
        form: {
            title: 'Contact Form',
            name: 'Dennis',
            email: '',
            message: 'Heel it now, dig?'
        } 
    },
    methods: {
        submit() {
            toast.innerHTML = 'Sending'
            submit.disabled = true
        
            const payload = {
                name: app.form.name,
                email: app.form.email,
                message: app.form.message
            }
            console.log(payload)
            post(url, payload, function (err,res)  {
                if (err) { return error(err) }
                success()
            })
        }
    }
})

function post(url, body, callback) {
    var req = new XMLHttpRequest();
    req.open("POST", url, true);
    req.setRequestHeader("Content-Type", "application/json");
    req.addEventListener("load", function() {
        if (req.status < 400) {
            callback(null, JSON.parse(req.responseText));
        } else {
            callback(new Error('Request failed: ' + req.statusText));
        }
    });
    req.send(JSON.stringify(body));
}
function success() {
    toast.innerHTML = 'Thanks for the message. We will get back to you shortly.'
    submit.disabled = false
    submit.blur
    form.name.focus()
    form.name.value = ''
    form.email.value = ''
    form.message.value = ''
}
function error (err) {
    toast.innerHTML = 'There was a problem submitting your message.'
    submit.disabled = false
    console.log(err)
}

